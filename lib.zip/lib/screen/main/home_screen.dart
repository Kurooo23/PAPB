import 'package:flutter/material.dart';

import 'package:rivnet/controllers/turnamen_controller.dart';
import 'package:rivnet/routes/app_routes.dart';
import 'package:rivnet/widgets/turnamen_card.dart';

class MainShell extends StatefulWidget {
  const MainShell({super.key});

  @override
  State<MainShell> createState() => _MainShellState();
}

class _MainShellState extends State<MainShell> {
  int _tabTerpilih = 0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(_tabTerpilih == 0 ? 'Turnamen' : 'Riwayat Turnamen'),
      ),
      body: IndexedStack(
        index: _tabTerpilih,
        children: const [
          DaftarTurnamen(riwayat: false),
          DaftarTurnamen(riwayat: true),
        ],
      ),
      floatingActionButton: _tabTerpilih == 0
          ? FloatingActionButton.extended(
              // Named Route
              onPressed: () =>
                  Navigator.pushNamed(context, Routes.createTurnament),
              icon: const Icon(Icons.add),
              label: const Text('Buat Turnamen'),
            )
          : null,
      bottomNavigationBar: NavigationBar(
        selectedIndex: _tabTerpilih,
        onDestinationSelected: (index) => setState(() => _tabTerpilih = index),
        destinations: const [
          NavigationDestination(
            icon: Icon(Icons.emoji_events_outlined),
            selectedIcon: Icon(Icons.emoji_events),
            label: 'Turnamen',
          ),
          NavigationDestination(
            icon: Icon(Icons.history),
            selectedIcon: Icon(Icons.history_toggle_off),
            label: 'Riwayat',
          ),
        ],
      ),
    );
  }
}

/// riwayat = false -> turnamen yang belum selesai
/// riwayat = true  -> turnamen yang sudah selesai
class DaftarTurnamen extends StatelessWidget {
  final bool riwayat;
  const DaftarTurnamen({super.key, required this.riwayat});

  @override
  Widget build(BuildContext context) {
    // Akses controller via singleton (bukan Get.find)
    final turnamenController = TurnamenController.instance;

    // AnimatedBuilder
    return AnimatedBuilder(
      animation: turnamenController,
      builder: (context, _) {
        final daftarTurnamen = turnamenController.turnamen
            .where(
              (turnamen) => riwayat
                  ? turnamen.status == 'Selesai'
                  : turnamen.status != 'Selesai',
            )
            .toList();

        if (daftarTurnamen.isEmpty) {
          return Center(
            child: Text(
              riwayat
                  ? 'Belum ada riwayat turnamen.'
                  : 'Belum ada turnamen.',
            ),
          );
        }
        return ListView.builder(
          padding: const EdgeInsets.fromLTRB(16, 16, 16, 90),
          itemCount: daftarTurnamen.length,
          itemBuilder: (_, indeks) => TurnamenCard(turnamen: daftarTurnamen[indeks]),
        );
      },
    );
  }
}
