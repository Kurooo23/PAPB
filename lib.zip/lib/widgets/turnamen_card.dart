import 'package:flutter/material.dart';

import 'package:rivnet/models/turnamen.dart';
import 'package:rivnet/routes/app_routes.dart';
import 'package:rivnet/themes/color.dart';

Color warnaStatus(String status) {
  switch (status) {
    case 'Akan Datang':
      return AppColors.primary;
    case 'Berlangsung':
      return AppColors.accent;
    default:
      return Colors.grey;
  }
}

class StatusChip extends StatelessWidget {
  final String status;
  const StatusChip(this.status, {super.key});

  @override
  Widget build(BuildContext context) {
    final warna = warnaStatus(status);
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        color: warna.withValues(alpha: 0.15),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: warna.withValues(alpha: 0.6)),
      ),
      child: Text(
        status,
        style: TextStyle(
          color: warna,
          fontSize: 12,
          fontWeight: FontWeight.w600,
        ),
      ),
    );
  }
}

class TurnamenCard extends StatelessWidget {
  final Turnamen turnamen;
  const TurnamenCard({super.key, required this.turnamen});

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        // Named Route pakai Navigator.pushNamed (bukan Get.toNamed)
        onTap: () => Navigator.pushNamed(
          context,
          Routes.detailTurnament,
          arguments: turnamen.id,
        ),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: AnimatedBuilder(
            animation: turnamen, // Turnamen extends ChangeNotifier
            builder: (context, _) {
              return Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Expanded(
                        child: Text(
                          turnamen.nama,
                          style: const TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                      StatusChip(turnamen.status),
                    ],
                  ),
                  const SizedBox(height: 12),
                  Row(
                    children: [
                      const Icon(
                        Icons.groups_outlined,
                        size: 16,
                        color: Colors.white54,
                      ),
                      const SizedBox(width: 6),
                      Text(
                        '${turnamen.peserta.length} peserta • '
                        '${turnamen.pertandingan.where((pertandingan) => pertandingan.selesai).length}'
                        '/${turnamen.pertandingan.length} match selesai',
                      ),
                    ],
                  ),
                ],
              );
            },
          ),
        ),
      ),
    );
  }
}
