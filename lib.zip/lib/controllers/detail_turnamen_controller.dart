import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'package:rivnet/controllers/turnamen_controller.dart';
import 'package:rivnet/models/klasemen.dart';
import 'package:rivnet/models/turnamen.dart';
import 'package:rivnet/routes/app_routes.dart';
import 'package:rivnet/utils/pesan.dart';

/// Controller untuk layar Detail Turnamen.
/// Dipakai oleh DetailTurnamentScreen (StatefulWidget).
/// Dibuat di initState layar
class DetailTurnamenController extends ChangeNotifier {
  Turnamen? data;
  List<KlasemenItem> klasemenTersimpan = [];
  bool _sudahHitungKlasemen = false;

  /// Ambil id turnamen dari argumen Named Route.
  void init(Object? args) {
    final id = args as String?;
    data = id == null ? null : TurnamenController.instance.cari(id);
    // Hitung klasemen sekali saat layar pertama kali dibuka,
    // supaya tetap fix walau skor pertandingan diubah.
    if (data != null && !_sudahHitungKlasemen) {
      klasemenTersimpan = hitungKlasemen(data!);
      _sudahHitungKlasemen = true;
    }
    notifyListeners();
  }

  Turnamen get turnamen => data!;

  // ---------------- Turnamen ----------------
  void ubahTurnamen(BuildContext context) {
    final turnamen = data;
    if (turnamen == null) return;
    Navigator.pushNamed(context, Routes.editTurnament, arguments: turnamen.id);
  }

  Future<void> hapusTurnamen(BuildContext context) async {
    final turnamen = data;
    if (turnamen == null) return;
    final ok = await konfirmasi(
      'Hapus turnamen?',
      '"${turnamen.nama}" beserta peserta dan hasil pertandingannya akan dihapus.',
    );
    if (!ok) return;
    // Fake delete: tampilkan pesan tapi jangan hapus data.
    tampilPesan('Berhasil menghapus');
  }

  // ---------------- Peserta ----------------
  Future<void> dialogPeserta(BuildContext context, {Peserta? ubah}) async {
    final turnamen = data!;
    final formKey = GlobalKey<FormState>();
    var namaInput = ubah?.nama ?? '';

    final ok = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: Text(ubah == null ? 'Tambah Peserta' : 'Edit Peserta'),
        content: Form(
          key: formKey,
          child: TextFormField(
            initialValue: namaInput,
            autofocus: true,
            decoration: const InputDecoration(labelText: 'Nama peserta / tim'),
            onChanged: (value) => namaInput = value,
            validator: (value) {
              final teks = (value ?? '').trim();
              if (teks.isEmpty) return 'Nama wajib diisi';
              final kembar = turnamen.peserta.any(
                (peserta) =>
                    peserta != ubah &&
                    peserta.nama.toLowerCase() == teks.toLowerCase(),
              );
              return kembar ? 'Nama sudah terdaftar' : null;
            },
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(dialogContext).pop(false),
            child: const Text('Batal'),
          ),
          FilledButton(
            onPressed: () {
              if (formKey.currentState!.validate()) {
                Navigator.of(dialogContext).pop(true);
              }
            },
            child: const Text('Simpan'),
          ),
        ],
      ),
    );

    if (ok != true) return;
    // Fake create/update: tampilkan pesan tapi jangan ubah data.
    if (ubah == null) {
      tampilPesan('Berhasil menambah peserta');
    } else {
      tampilPesan('Berhasil mengedit peserta');
    }
  }

  Future<void> hapusPeserta(BuildContext context, Peserta peserta) async {
    final ok = await konfirmasi(
      'Hapus peserta?',
      '"${peserta.nama}" dan semua pertandingannya akan dihapus.',
    );
    if (!ok) return;
    // Fake delete: tampilkan pesan tapi jangan hapus data.
    tampilPesan('Berhasil menghapus peserta');
  }

  // ---------------- Pertandingan ----------------
  Future<void> buatPertandingan(BuildContext context) async {
    final turnamen = data!;
    if (turnamen.peserta.length < 2) {
      tampilPesan('Peserta kurang dari 2', error: true);
      return;
    }

    if (turnamen.pertandingan.isNotEmpty) {
      final adaSkor = turnamen.pertandingan.any(
        (pertandingan) => pertandingan.selesai,
      );
      final ok = await konfirmasi(
        'Buat ulang pertandingan?',
        adaSkor
            ? 'Pertandingan lama beserta semua skor yang sudah diisi akan diganti.'
            : 'Pertandingan lama akan diganti.',
        tombol: 'Buat Ulang',
      );
      if (!ok) return;
    }

    // Fake create: tampilkan pesan tapi jangan ubah data.
    tampilPesan('Berhasil membuat pertandingan');
  }

  Future<void> dialogSkor(BuildContext context, Pertandingan pertandingan) async {
    final turnamen = data!;
    final formKey = GlobalKey<FormState>();
    var skorA = pertandingan.skorA?.toString() ?? '';
    var skorB = pertandingan.skorB?.toString() ?? '';
    final namaA = turnamen.namaPeserta(pertandingan.idA);
    final namaB = turnamen.namaPeserta(pertandingan.idB);

    String? wajibAngka(String? value) =>
        int.tryParse((value ?? '').trim()) == null ? 'Isi angka' : null;

    Widget kolomSkor(
      String nama,
      String nilaiAwal,
      void Function(String) ubah,
    ) {
      return Expanded(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text(
              nama,
              textAlign: TextAlign.center,
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(fontWeight: FontWeight.w600),
            ),
            const SizedBox(height: 12),
            TextFormField(
              initialValue: nilaiAwal,
              textAlign: TextAlign.center,
              keyboardType: TextInputType.number,
              inputFormatters: [FilteringTextInputFormatter.digitsOnly],
              style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
              onChanged: ubah,
              validator: wajibAngka,
            ),
          ],
        ),
      );
    }

    final ok = await showDialog<bool>(
      context: context,
      barrierDismissible: false,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Masukkan Skor'),
        insetPadding: const EdgeInsets.symmetric(horizontal: 24, vertical: 24),
        contentPadding: const EdgeInsets.fromLTRB(24, 8, 24, 8),
        content: SingleChildScrollView(
          child: Form(
            key: formKey,
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                kolomSkor(namaA, skorA, (value) => skorA = value),
                const Padding(
                  padding: EdgeInsets.fromLTRB(12, 44, 12, 0),
                  child: Text('-', style: TextStyle(fontSize: 22)),
                ),
                kolomSkor(namaB, skorB, (value) => skorB = value),
              ],
            ),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(dialogContext).pop(false),
            child: const Text('Batal'),
          ),
          FilledButton(
            onPressed: () {
              if (formKey.currentState!.validate()) {
                Navigator.of(dialogContext).pop(true);
              }
            },
            child: const Text('Simpan'),
          ),
        ],
      ),
    );

    if (ok != true) return;
    // Fake update: tampilkan pesan tapi jangan ubah skor asli.
    tampilPesan('Berhasil menyimpan skor');
  }
}
