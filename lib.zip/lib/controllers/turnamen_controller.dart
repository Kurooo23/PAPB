import 'package:flutter/foundation.dart';

import 'package:rivnet/data/dummy_data.dart';
import 'package:rivnet/models/turnamen.dart';

class TurnamenController extends ChangeNotifier {
  static final TurnamenController instance = TurnamenController._();

  TurnamenController._() {
    turnamen.addAll(buatDummyTurnamen());
  }

  final List<Turnamen> turnamen = [];

  void tambah(Turnamen turnamenBaru) {
    turnamen.insert(0, turnamenBaru);
  }

  void hapus(String id) {
    turnamen.removeWhere((item) => item.id == id);
  }

  Turnamen? cari(String id) {
    for (final item in turnamen) {
      if (item.id == id) return item;
    }
    return null;
  }
}
