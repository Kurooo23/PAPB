import 'package:rivnet/models/turnamen.dart';

const List<String> dummyGame = ['Sepak Bola'];

Turnamen _buat({
  required String nama,
  required String game,
  required String status,
  required List<String> peserta,
  required List<List<int>> hasil,
  int leg = 1,
}) {
  final turnamen = Turnamen(
    id: buatId('trn'),
    nama: nama,
    game: game,
    leg: leg,
    status: status,
  );
  for (final namaPeserta in peserta) {
    turnamen.peserta.add(Peserta(id: buatId('p'), nama: namaPeserta));
  }
  for (final hasilMatch in hasil) {
    turnamen.pertandingan.add(
      Pertandingan(
        id: buatId('m'),
        idA: turnamen.peserta[hasilMatch[0]].id,
        idB: turnamen.peserta[hasilMatch[1]].id,
        skorA: hasilMatch[2],
        skorB: hasilMatch[3],
      ),
    );
  }
  return turnamen;
}

Turnamen buatTurnamenBaru({required String nama, required String game}) {
  final peserta = ['Tim Alpha', 'Tim Beta', 'Tim Gamma', 'Tim Delta'];
  final hasil = [
    [0, 1, 2, 1],
    [2, 3, 0, 2],
    [0, 2, 3, 1],
    [1, 3, 1, 1],
    [0, 3, 2, 0],
    [1, 2, 0, 3],
  ];
  return _buat(
    nama: nama,
    game: game,
    status: 'Berlangsung',
    peserta: peserta,
    hasil: hasil,
  );
}

List<Turnamen> buatDummyTurnamen() => [
  _buat(
    nama: 'Rivnet Cup Season 1',
    game: 'Sepak Bola',
    status: 'Berlangsung',
    peserta: [
      'Borneo Muda FC',
      'Persiba Junior',
      'Mahakam United',
      'Samarinda City',
    ],
    hasil: [
      [0, 1, 2, 1],
      [2, 3, 1, 3],
      [0, 2, 3, 0],
      [1, 3, 2, 2],
      [0, 3, 1, 0],
      [1, 2, 0, 1],
    ],
  ),
  _buat(
    nama: 'Kalimantan Open Cup',
    game: 'Sepak Bola',
    status: 'Berlangsung',
    peserta: [
      'Pesut Etam FC',
      'Tenggarong SC',
      'Bontang Selection',
      'Penajam Rangers',
    ],
    hasil: [
      [0, 1, 2, 1],
      [2, 3, 0, 2],
      [0, 3, 3, 1],
      [1, 2, 1, 1],
      [0, 2, 2, 0],
      [1, 3, 1, 3],
    ],
  ),
  _buat(
    nama: 'Liga Mahasiswa Balikpapan',
    game: 'Sepak Bola',
    status: 'Selesai',
    peserta: ['FT Garuda', 'FE Elang', 'FK Rajawali', 'FH Bhayangkara'],
    hasil: [
      [0, 1, 3, 1],
      [2, 3, 2, 2],
      [0, 2, 1, 0],
      [1, 3, 0, 2],
      [0, 3, 2, 2],
      [1, 2, 1, 3],
    ],
  ),
  _buat(
    nama: 'Piala Kemerdekaan 2025',
    game: 'Sepak Bola',
    status: 'Selesai',
    peserta: ['RT 05 FC', 'Karang Taruna Jaya', 'Bintang Timur'],
    hasil: [
      [0, 1, 4, 2],
      [1, 2, 1, 1],
      [0, 2, 3, 0],
    ],
  ),
];
